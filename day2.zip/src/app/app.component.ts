import { Component } from '@angular/core';


@Component({    //@Component : annotation or decorator 

  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

})
export class AppComponent {
  
}
